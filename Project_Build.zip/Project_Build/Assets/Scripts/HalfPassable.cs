﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class HalfPassable : MonoBehaviour
{
    public GameObject Player;
    Rigidbody2D rb;

    void Start()
    {
        rb = Player.GetComponent<Rigidbody2D>();
    }
    void Update()
    {
        if (rb.velocity.y > 0)
        {
            Physics2D.IgnoreLayerCollision(10, 12, true);
        }
        else
        {
            Physics2D.IgnoreLayerCollision(10, 12, false);
        }
    }
}
