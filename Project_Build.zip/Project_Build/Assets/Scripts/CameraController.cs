﻿using Cinemachine;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CameraController : MonoBehaviour
{
    public GameObject Player;
    public GameObject Level1;
    public GameObject Level1_bonus;
    public GameObject Level2;
    public GameObject Level3;
    public GameObject Level4;
    public GameObject Level4_bonus;
    CinemachineConfiner cc;

    void Start()
    {
        cc = GetComponent<CinemachineConfiner>();
        Level1 = GameObject.Find("Level1");
        Level1_bonus = GameObject.Find("Level1_bonus");
        Level2 = GameObject.Find("Level2");
        Level3 = GameObject.Find("Level3");
        Level4 = GameObject.Find("Level4");
        Level4_bonus = GameObject.Find("Level4_bonus");
    }

    void Update()
    {
        if (Player.transform.position.x < 17.5 && Player.transform.position.y < 16)
        {
            cc.m_BoundingShape2D = Level1.GetComponent<PolygonCollider2D>();
        }
        if (Player.transform.position.x > 17.5 && Player.transform.position.y < 16)
        {
            cc.m_BoundingShape2D = Level1_bonus.GetComponent<PolygonCollider2D>();
        }

        if (Player.transform.position.x < -19.5 && Player.transform.position.y < 16)
        {
            cc.m_BoundingShape2D = Level2.GetComponent<PolygonCollider2D>();
        }

        if (Player.transform.position.x < -19.5 && Player.transform.position.y > 16)
        {
            cc.m_BoundingShape2D = Level3.GetComponent<PolygonCollider2D>();
        }

        if (Player.transform.position.x > -19.5 && Player.transform.position.y > 16)
        {
            cc.m_BoundingShape2D = Level4.GetComponent<PolygonCollider2D>();
        }
        if (Player.transform.position.x > 35.5 && Player.transform.position.y > 16)
        {
            cc.m_BoundingShape2D = Level4_bonus.GetComponent<PolygonCollider2D>();
        }
    }
}
