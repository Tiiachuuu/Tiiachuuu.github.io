﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Projectile : MonoBehaviour
{
    Rigidbody2D rb;

    void Awake()
    {
        rb = GetComponent<Rigidbody2D>();
    }

    public void Launch(bool yes)
    {
        if (yes)
        {
            rb.AddForce(transform.right * 600);
        }
        else
        {
            rb.AddForce(-transform.right * 600);
        }
    }

    void OnCollisionEnter2D(Collision2D other)
    {
        Box box = other.collider.GetComponent<Box>();
        if (other.gameObject.tag == "Box")
        {
            box.Break();
        }
        Destroy(gameObject);
    }
}
