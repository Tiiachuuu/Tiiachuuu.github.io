﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Player : MonoBehaviour
{
    float horizontal; float vertical;

    public int extraJumps;
    public float jumpforce = 10.0f;
    public float moveInput;
    public float checkRadius;
    public float speed = 5.0f;

    private int extraJumpValue = 1;
    private bool isGrounded;
    private bool isAlsoGrounded;
    private bool facingRight = true;
    Vector2 lookDirection = new Vector2(1, 0);

    public Text txtYellows, txtGreens, txtBlues, txtReds;
    public int maxYellows = 20, maxGreens = 15, maxBlues = 12, maxReds = 10;
    public int yellows { get { return currentYellows; } }
    public int greens { get { return currentGreens; } }
    public int blues { get { return currentBlues; } }
    public int reds { get { return currentReds; } }
    int currentYellows, currentGreens, currentBlues, currentReds;

    public Transform GroundCheck; public LayerMask whatIsGround; public LayerMask whatIsAlsoGround;
    public GameObject Projectile;
    Rigidbody2D rb;
    Animator animator;

    void Start()
    {
        rb = GetComponent<Rigidbody2D>();
        animator = GetComponent<Animator>();
        extraJumps = extraJumpValue;
        currentYellows = 0; currentGreens = 0; currentBlues = 0; currentReds = 0;
    }

    void Update()
    {
        float horizontal = Input.GetAxis("Horizontal");
        float vertical = Input.GetAxis("Vertical");
        Vector2 move = new Vector2(horizontal, vertical);

        if (!Mathf.Approximately(move.x, 0.0f) || !Mathf.Approximately(move.y, 0.0f))
        {
            lookDirection.Set(move.x, move.y);
            lookDirection.Normalize();
        }

        animator.SetFloat("Look X", lookDirection.x);
        animator.SetFloat("Look Y", lookDirection.y);
        animator.SetFloat("Speed", move.magnitude);

        if (isGrounded == true || isAlsoGrounded)
        {
            extraJumps = extraJumpValue;
        }
        if (Input.GetKeyDown(KeyCode.W) && extraJumps > 0 || Input.GetKeyDown(KeyCode.Space) && extraJumps > 0 || Input.GetKeyDown(KeyCode.UpArrow) && extraJumps > 0)
        {
            rb.velocity = Vector2.up * jumpforce;
            extraJumps--;
        }
        else if (Input.GetKeyDown(KeyCode.W) && extraJumps == 0 && isGrounded == true || Input.GetKeyDown(KeyCode.Space) && extraJumps == 0 && isGrounded == true || Input.GetKeyDown(KeyCode.UpArrow) && extraJumps == 0 && isGrounded == true ||
            Input.GetKeyDown(KeyCode.W) && extraJumps == 0 && isAlsoGrounded == true || Input.GetKeyDown(KeyCode.Space) && extraJumps == 0 && isAlsoGrounded == true || Input.GetKeyDown(KeyCode.UpArrow) && extraJumps == 0 && isAlsoGrounded == true)
        {
            rb.velocity = Vector2.up * jumpforce;
        }
    }

    void FixedUpdate()
    {
        isGrounded = Physics2D.OverlapCircle(GroundCheck.position, checkRadius, whatIsGround);
        isAlsoGrounded = Physics2D.OverlapCircle(GroundCheck.position, checkRadius, whatIsAlsoGround);

        moveInput = Input.GetAxis("Horizontal");
        rb.velocity = new Vector2(moveInput * speed, rb.velocity.y);

        if (!facingRight && moveInput > 0)
        {
            Flip();
        }
        else if (facingRight && moveInput < 0)
        {
            Flip();
        }

        txtYellows.text = currentYellows + "/40";
        txtGreens.text = currentGreens + "/30";
        txtBlues.text = currentBlues + "/20";
        txtReds.text = currentReds + "/20";

        if (Input.GetKeyDown(KeyCode.F))
        {
            Launch();
        }
    }

    void Flip()
    {
        facingRight = !facingRight;
    }

    public void AddYellow()
    {
        currentYellows++;
        YellowKey.instance.SetValue(currentYellows / (float)maxYellows);
    }
    public void AddGreen()
    {
        currentGreens++;
        GreenKey.instance.SetValue(currentGreens / (float)maxGreens);
    }
    public void AddBlue()
    {
        currentBlues++;
        BlueKey.instance.SetValue(currentBlues / (float)maxBlues);
    }
    public void AddRed()
    {
        currentReds++;
        RedKey.instance.SetValue(currentReds / (float)maxReds);
    }

    void Launch()
    {
        GameObject ProjectileObject = Instantiate(Projectile, rb.position, Quaternion.identity);
        Projectile projectile = ProjectileObject.GetComponent<Projectile>();
        projectile.Launch(facingRight);
        animator.SetTrigger("Shoot");
    }

    void OnTriggerEnter2D(Collider2D col)
    {
        if (col.gameObject.tag == "Yellow")
        {
            AddYellow();
            Destroy(col.gameObject);
        }
        if (col.gameObject.tag == "Green")
        {
            AddGreen();
            Destroy(col.gameObject);
        }
        if (col.gameObject.tag == "Blue")
        {
            AddBlue();
            Destroy(col.gameObject);
        }
        if (col.gameObject.tag == "Red")
        {
            AddRed();
            Destroy(col.gameObject);
        }
        if (col.gameObject.tag == "End")
        {
            this.transform.position = new Vector2(0,0);
        }
    }

    void OnCollisionEnter2D(Collision2D col)
    {
        if (col.gameObject.tag == "LockY" && currentYellows >= maxYellows)
        {
            Destroy(col.gameObject);
        }
        if (col.gameObject.tag == "LockG" && currentGreens >= maxGreens)
        {
            Destroy(col.gameObject);
        }
        if (col.gameObject.tag == "LockB" && currentBlues >= maxBlues)
        {
            Destroy(col.gameObject);
        }
        if (col.gameObject.tag == "LockR" && currentReds >= maxReds)
        {
            Destroy(col.gameObject);
        }
    }
}